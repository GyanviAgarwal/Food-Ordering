var searchData=
[
  ['validate_5frid_0',['validate_RID',['../class_project___code___v0__812_1_1_r_e_s_t_a_u_r_a_n_t.html#a3f88e9ba62b030ee0dc98a748318a75f',1,'Project_Code_V0_812::RESTAURANT']]]
];
