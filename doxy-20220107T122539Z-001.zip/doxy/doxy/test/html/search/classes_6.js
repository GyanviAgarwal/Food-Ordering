var searchData=
[
  ['user_0',['USER',['../class_project___code___v0__812_1_1_u_s_e_r.html',1,'Project_Code_V0_812']]],
  ['user_5finfo_1',['USER_Info',['../class_project___code___v0__812_1_1_u_s_e_r___info.html',1,'Project_Code_V0_812']]]
];
