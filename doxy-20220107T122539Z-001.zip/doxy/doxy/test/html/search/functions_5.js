var searchData=
[
  ['signin_0',['SignIn',['../class_project___code___v0__812_1_1_u_s_e_r.html#a58b399e842ebe6d7d4874e517c7c29e0',1,'Project_Code_V0_812::USER']]],
  ['signup_1',['SignUp',['../class_project___code___v0__812_1_1_u_s_e_r.html#a04f1b8adde8892ba7392cf2325ea1b0d',1,'Project_Code_V0_812::USER']]],
  ['start_2',['start',['../class_project___code___v0__812_1_1_time_tracker.html#ae0b63d1e694bdbabe28faa7178fddb37',1,'Project_Code_V0_812::TimeTracker']]]
];
